package cookGame;
 
public class Customer extends Entity {
 
    private final int maxPatience;
 
    private int patience;
 
    private int foodWanted;
 
    private boolean fed;
 
    public Customer(int maxPatience, int x, int y) {
        this(maxPatience, x, y, 1);         //calls four argument constructor with red food wanted
        fed = false;
    }
 
    public Customer(int maxPatience, int x, int y, int foodType) {
        this.maxPatience = maxPatience;
        this.patience = maxPatience;
        setPosition(x, y);
        if (foodType < 1 || foodType > 3) {
            foodType = 1;
        }
        foodWanted = foodType;
        fed = false;
    }
 
    public void changePatience(int change) {
        patience += change;
        if (patience > maxPatience) {
            patience = maxPatience;
        }
        if (patience < 0) {
            patience = 0;
        }
    }

    
    public int getPatience() {
        return patience;
    }
 
    public int getMaxPatience() {
        return maxPatience;
    }
 
    public int getFoodWanted() {
        return foodWanted;
    }
 
    public void feed() {
        fed = true;
    }
 
    public boolean beenFed() {
        return fed;
    }

}
