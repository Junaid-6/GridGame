package cookGame;

import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.Point;
import java.util.Random;

public class GameEngine {
 
    public enum TileType {
        WALL, FLOOR1, FLOOR2, FOOD1, FOOD2, FOOD3, TABLE, DOOR, SCORE;
    }
 
    public static final int LEVEL_WIDTH = 35;
 
    public static final int LEVEL_HEIGHT = 18;
 
    private Random rng = new Random();
    public static boolean GameEnded = false;
 
    private static int levelNumber = 1;   
    public static int getlevel(){
        return levelNumber;
    }
     
    private static int turnNumber = 0;
    public static int getstep(){
        return turnNumber;
    }
    
    private static int score = 0;
    public static int getscore(){
        return score;
    }

    private static int lifes = 4; 
    public static void setLifes(int life) {
    	lifes = life;
    }
    public static int  getLife() {
    	return lifes;
    }

    private GameGUI gui;
    
    private TileType[][] level;
 
    private ArrayList<Point> spawnLocations;

     
    private Player player;
 
    private Customer[] customers;
 
    public GameEngine(GameGUI gui) {
        this.gui = gui;
    }
 
    private TileType[][] generateLevel() { 
       level = new TileType[34][17];       
       for(int i = 0; i < 34; i++){
           for(int j=0; j < 17; j++){
               level[i][j] = TileType.FLOOR1;
               level[0][j] = TileType.WALL;
               level[33][j] = TileType.WALL;
           }
           level[i][0] = TileType.WALL;
           level[i][16] = TileType.WALL;           
       } 
       level[32][2] = TileType.FOOD1;
       level[30][2] = TileType.FOOD2;
       level[28][2] = TileType.FOOD3;
       
       for (int i = 3; i < 20; i += 5){
           for(int j=2; j < level[0].length-1; j += 4){
               level[i][j] = TileType.TABLE;               
           }
       }
       
       level[30][15] = TileType.SCORE;
        return level;  
    }
 
    private ArrayList<Point> getSpawns() { 
        spawnLocations = new ArrayList();
        int index = 0;
        for(int i=1; i < level.length-15; i++){
            for(int j=1; j < level[0].length-1; j++){
                if(level[i][j] == TileType.FLOOR1 || level[i][j] == TileType.FLOOR2){
                    System.out.print(10*i+j);
                Point p = new Point(i,j);
                spawnLocations.add(index,p);
                index++;
                }
            }
        }        
        return spawnLocations;     
    }
    
    private Customer[] addCustomers() { 
        customers = new Customer[24];
        int foodtype, index, x, y;
        Point p;
        if(levelNumber==1)
            for (int i = 0; i < 4; i++){
                foodtype = rng.nextInt(1,4);
                index = rng.nextInt(spawnLocations.size());
                 p = spawnLocations.get(index);
                 x = p.x;
                 y = p.y;
                 spawnLocations.remove(index);
                customers[i] = new Customer(200,x,y,foodtype);
            }      
        return customers;     
    }
 
    private Player createPlayer() { 
        player = new Player(500,30,4);
        return player;   
    }
    
    public void movePlayer(char direction) { 
        int x = this.player.getX();
        int y = this.player.getY();
        switch(direction){
            case 'U':
                y--;
                break;
            case 'D':
                y++;
                break;
            case 'L':
                x--;
                break;
            case 'R':
                x++;
                break;
        }
        if(level[x][y] == TileType.FOOD1)
            this.player.grabFood(1);
        else if(level[x][y] == TileType.FOOD2)
            this.player.grabFood(2);
        else if(level[x][y] == TileType.FOOD3)
            this.player.grabFood(3);
        for (Customer customer : customers) {
            int cx, cy;
            if (customer != null) {
                cx = customer.getX();
                cy = customer.getY();
                if (cx == x && cy == y && customer.getFoodWanted()==this.player.getCarriedFoodType()) {
                    deliverFood(customer);
                }
            }
        }
        boolean nextC = false;
        for (Customer customer : customers) {
            if (customer != null) {
                int NCx = customer.getX();
                int NCy = customer.getY();
                if( NCx==x && NCy==y){
                    nextC = true;
                    break;
                }
            }
        }
        if(level[x][y] == TileType.FLOOR1 ||  level[x][y] == TileType.DOOR )
            if(!nextC){
                this.player.setPosition(x, y);
            }
       if(level[x][y] == TileType.WALL) {
    	   setLifes(getLife()-1);
    	   this.player.setPosition(x, y);
    	   this.player.setPosition(30, 5);
           this.player.changeStamina(-125);
       }
      
    }
 
    private void deliverFood(Customer c) { 
        if(this.player.getCarriedFoodType()== c.getFoodWanted()){
            c.feed();
            this.player.giveFood();
            c.changePatience(10);
            score += c.getPatience();
            this.player.changeStamina(c.getPatience()); 
            if(this.score > 500) {
            	setLifes(getLife()+1);
            	this.score = 0;
            }
            level[30][15] = TileType.SCORE;
            
        }
       
    }

    
    private void moveCustomer(Customer c) { 
        int cx = c.getX();
        int cy = c.getY();
        int move = rng.nextInt(4);
        //searching nearest table
        double near_tab_dist = Math.sqrt(cx*cx + cy*cy);
        int x = cx, y = cy;
        for(int i = 0 ; i < level.length; i++){
            for(int j = 0; j < level[0].length; j++){
                if(level[i][j]==TileType.TABLE)
                    for (Customer customer : customers) {
                    if (customer != null) {
                        if ((customer.getX() != i-1 || customer.getX() != i+1) && customer.getY() != j) {
                            if(near_tab_dist > Math.sqrt((cx-i)*(cx-i) + (cy -j)*(cy -j))){
                                near_tab_dist = Math.sqrt((cx-i)*(cx-i) + (cy -j)*(cy -j));
                                x = i;
                                y = j;
                            }
                        }                    
                    }
                }                        
            }
        }             
        if(cx < x )
            move = 3;
        else if(cx > x)
            move = 2;
        if(cy < y)
            move = 0;
        else if(cy > y)
            move = 1;     
        
        boolean food_arrive = false;
        boolean nextC = false;
        for(int i = cx - 3; i < cx + 3; i++)
            for(int j = cy - 3; j < cy + 3; j++)
                if(i == this.player.getX() && j == this.player.getY() && this.player.hasFood()){
                            food_arrive = true;
                            break;
                }             
        if(!food_arrive){            
        switch(move){
            case 0:
                cy += 1;
                break;
            case 1:
                cy -= 1;
                break;
            case 2:
                cx -= 1;
                break;
            case 3:
                cx += 1;
                break;
        }        
        for (Customer customer : customers) {
            if (customer != null) {
                int NCx = customer.getX();
                int NCy = customer.getY();
                if( NCx==cx && NCy==cy){
                    nextC = true;
                    break;
                }
            }
        }        
        if (level[cx][cy] == TileType.TABLE )
            cx--;
        if(!nextC)
            if(level[cx][cy] == TileType.FLOOR1 || level[cx][cy] == TileType.FLOOR2 || level[cx][cy] == TileType.DOOR ){                    
                    c.setPosition(cx, cy);
            }        
            else
                 cx--;
    }       
}
    
    private void moveAllCustomers() { 
        for (Customer customer : customers) {
            if (customer != null) {
                int x = customer.getX();
                int y = customer.getY();
                if (level[x-1][y] != TileType.TABLE && level[x+1][y] != TileType.TABLE) {                    
                    moveCustomer(customer);
                }
            }
        }
       
    }
 
    private void cleanFedCustomers() { 
        for(int i = 0; i < customers.length; i++){
            if(customers[i] != null)
                if(customers[i].beenFed())
                    customers[i] = null;            
        }
    }
 
    private void nextLevel() { 
        levelNumber++;
        placePlayer();
        System.out.print(levelNumber);
        int foodtype, index, x, y;
        Point p;
        if(levelNumber >= 4 ){
            for (TileType[] level1 : level) 
                for (int j = 0; j < level[0].length; j++) 
                    level1[j] = TileType.SCORE;                            
        }
        else if(levelNumber == 2){           
            for (int i = 0; i < 10; i++){
                foodtype = rng.nextInt(1,4);
                index = rng.nextInt(spawnLocations.size());
                 p = spawnLocations.get(index);
                 x = p.x;
                 y = p.y;
                 spawnLocations.remove(index);
                customers[i] = new Customer(150,x,y,foodtype);
            }            
            for(int i=0; i<level[0].length; i += 2){
                level[20][i] = TileType.WALL;
                if(i < level[0].length-1)
                    level[20][i+1] = TileType.DOOR;
            }
        }
        else if(levelNumber == 3){
            
            for (int i = 0; i < 18; i++){
                foodtype = rng.nextInt(1,4);
                index = rng.nextInt(spawnLocations.size());
                 p = spawnLocations.get(index);
                 x = p.x;
                 y = p.y;
                 spawnLocations.remove(index);
                customers[i] = new Customer(150,x,y,foodtype);
            }
            for(int i=0; i<level[0].length; i++){
                level[20][i] = TileType.WALL;                    
            }
            level[20][1] = TileType.DOOR;
            level[20][7] = TileType.DOOR;
        } 
        else if(levelNumber == 4){            
            for (int i = 0; i < 24; i++){
                foodtype = rng.nextInt(1,4);
                index = rng.nextInt(spawnLocations.size());
                 p = spawnLocations.get(index);
                 x = p.x;
                 y = p.y;
                 spawnLocations.remove(index);
                customers[i] = new Customer(150,x,y,foodtype);
            }
            for(int i=0; i<level[0].length; i++){
                level[20][i] = TileType.WALL;
                
            }
            level[20][1] = TileType.DOOR;
        }
        
    }
 
    private void placePlayer() { 
        int x, y;
        int index = rng.nextInt(spawnLocations.size());
        Point p = spawnLocations.get(index);
         x = p.x;
         y = p.y;        
        this.player.setPosition(x, y);
        spawnLocations.remove(index);           
        
    }
    
    private boolean allCustomersFed() { 
        boolean feeded = false;
        for (Customer customer : customers) {
            if (customer == null) {
                continue;
            }
            if (!customer.beenFed()) {
                feeded = false;
                break;
            } 
            else {
                feeded = true;              
            }
        }
        return feeded;   
    }
 
    private void reduceCustomerPatience() { 
         for (Customer customer : customers) {
            if (customer == null) {
                continue;
            }
            int x = customer.getX();
            int y = customer.getY();
            if(level[x+1][y] == TileType.TABLE || level[x-1][y] == TileType.TABLE){
                customer.changePatience(-1);
            }
            else {
                customer.changePatience(-5);
            }
        }
    }

  
    public void doTurn() {  
    	    	 
    	if(GameEnded) {
    		return;
    	}
        if(allCustomersFed())
                nextLevel();
                
        if(this.player.getStamina()<= 20)
            this.player.changeStamina(1);
         
        turnNumber++;
        if (turnNumber % 10 == 0) {
            cleanFedCustomers();
        }
        if (turnNumber % 3 == 0) {
            moveAllCustomers();
            reduceCustomerPatience();            
        }
        gui.updateDisplay(level, player, customers);
    }
 
    public void startGame() {
        level = generateLevel();
        spawnLocations = getSpawns();
        customers = addCustomers();
        player = createPlayer();
        gui.updateDisplay(level, player, customers);
    }
}
