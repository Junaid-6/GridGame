package cookGame;
 
public class Player extends Entity {
 
    private final int maxStamina;

    private int stamina;
 
    private boolean carryingFood;
 
    private int carriedFoodType;
 
    public Player(int maxStamina, int x, int y) {
        this.maxStamina = maxStamina;
        this.stamina = maxStamina; 
        carryingFood = false;
        carriedFoodType = 0;
        setPosition(x, y);
    }

   
    public void changeStamina(int change) {
        stamina += change;
        if (stamina > maxStamina) {
            stamina = maxStamina;
        }
        if (stamina < 0) {
            stamina = 0;
        }
    }
 
    public int getStamina() {
        return stamina;
    }
 
    public int getMaxStamina() {
        return maxStamina;
    }
 
    public boolean hasFood() {
        return carryingFood;
    }
 
    public int getCarriedFoodType() {
        return carriedFoodType;
    }
 
    public void grabFood(int type) {
        carryingFood = true;
        carriedFoodType = type;
    }
 
    public void giveFood() {
        carryingFood = false;
        carriedFoodType = 0;
    }
}
