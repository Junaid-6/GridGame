package cookGame;
 
public abstract class Entity {
 
    private int xPos;
 
    private int yPos;
 
    public int getX() {
        return xPos;
    }
 
    public int getY() {
        return yPos;
    }
 
    public void setPosition(int x, int y) {
        xPos = x;
        yPos = y;
    }

}
