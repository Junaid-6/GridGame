package cookGame;

import java.awt.EventQueue;
 
public class Launcher {

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
 
            @Override
            public void run() {
                GameGUI gui = new GameGUI();            //create GUI
                gui.setVisible(true);                   //display GUI
                GameEngine eng = new GameEngine(gui);   //create engine
                InputHandler i = new InputHandler(eng); //create input handler
                gui.registerKeyHandler(i);              //registers handler with GUI
                eng.startGame();                        //starts the game
            }
        });
    }

}
