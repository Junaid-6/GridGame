package cookGame;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
 
public class InputHandler implements KeyListener {

    GameEngine engine;     
    public InputHandler(GameEngine eng) {
        engine = eng;
    }
 
    @Override
    public void keyTyped(KeyEvent e) {
    }
 
    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                engine.movePlayer('L');
                break;  //handle left arrow key
            case KeyEvent.VK_RIGHT:
                engine.movePlayer('R');
                break;//handle right arrow
            case KeyEvent.VK_UP:
                engine.movePlayer('U');
                break;      //handle up arrow
            case KeyEvent.VK_DOWN:
                engine.movePlayer('D');
                break;  //handle down arrow
        }
        engine.doTurn();    //any key press will result in this method being called
    }
 
    @Override
    public void keyReleased(KeyEvent e) {
    }

}
