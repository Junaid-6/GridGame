package cookGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import cookGame.GameEngine.TileType;

 
public class GameGUI extends JFrame {
 
    public static final int TILE_WIDTH = 32;
    public static final int TILE_HEIGHT = 32;
    public static final int BAR_HEIGHT = 3;
 
    Canvas canvas;
 
    public GameGUI() {
        initGUI();
    }
 
    public void registerKeyHandler(InputHandler i) {
        addKeyListener(i);
    }
 
    private void initGUI() {
        add(canvas = new Canvas());     //adds canvas to this frame
        setTitle("BowlDown");
        setSize(1136, 615);
        setLocationRelativeTo(null);        //sets position of frame on screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
 
    public void updateDisplay(TileType[][] tiles, Player player, Customer[] customers) {
        canvas.update(tiles, player, customers);
    }
}
 
class Canvas extends JPanel {
    
    private BufferedImage floor1;
    private BufferedImage floor2;
    private BufferedImage wall;
    private BufferedImage player;
    private BufferedImage playerfood1;
    private BufferedImage playerfood2;
    private BufferedImage playerfood3;
    private BufferedImage customer1;
    private BufferedImage customer2;
    private BufferedImage customer3;
    private BufferedImage door;
    private BufferedImage food1;
    private BufferedImage food2;
    private BufferedImage food3;
    private BufferedImage table;
    private BufferedImage board;
    GameEngine t;
    
    TileType[][] currentTiles;  
    Player currentPlayer;        
    Customer[] currentCustomers;    
 
    public Canvas() {
        loadTileImages();
    }
 
    private void loadTileImages() {
        try {
            floor1 = ImageIO.read(new File("assets/floor1.png"));
            assert floor1.getHeight() == GameGUI.TILE_HEIGHT
                    && floor1.getWidth() == GameGUI.TILE_WIDTH;
            floor2 = ImageIO.read(new File("assets/floor2.png"));
            assert floor2.getHeight() == GameGUI.TILE_HEIGHT
                    && floor2.getWidth() == GameGUI.TILE_WIDTH;
            wall = ImageIO.read(new File("assets/wall.png"));
            assert wall.getHeight() == GameGUI.TILE_HEIGHT
                    && wall.getWidth() == GameGUI.TILE_WIDTH;
            player = ImageIO.read(new File("assets/player.png"));
            assert player.getHeight() == GameGUI.TILE_HEIGHT
                    && player.getWidth() == GameGUI.TILE_WIDTH;
            playerfood1 = ImageIO.read(new File("assets/playerfood.png"));
            assert playerfood1.getHeight() == GameGUI.TILE_HEIGHT
                    && playerfood1.getWidth() == GameGUI.TILE_WIDTH;
            playerfood2 = ImageIO.read(new File("assets/playerfood2.png"));
            assert playerfood2.getHeight() == GameGUI.TILE_HEIGHT
                    && playerfood2.getWidth() == GameGUI.TILE_WIDTH;
            playerfood3 = ImageIO.read(new File("assets/playerfood3.png"));
            assert playerfood3.getHeight() == GameGUI.TILE_HEIGHT
                    && playerfood3.getWidth() == GameGUI.TILE_WIDTH;
            customer1 = ImageIO.read(new File("assets/customer.png"));
            assert customer1.getHeight() == GameGUI.TILE_HEIGHT
                    && customer1.getWidth() == GameGUI.TILE_WIDTH;
            customer2 = ImageIO.read(new File("assets/customer2.png"));
            assert customer2.getHeight() == GameGUI.TILE_HEIGHT
                    && customer2.getWidth() == GameGUI.TILE_WIDTH;
            customer3 = ImageIO.read(new File("assets/customer3.png"));
            assert customer3.getHeight() == GameGUI.TILE_HEIGHT
                    && customer3.getWidth() == GameGUI.TILE_WIDTH;
            food1 = ImageIO.read(new File("assets/food.png"));
            assert food1.getHeight() == GameGUI.TILE_HEIGHT
                    && food1.getWidth() == GameGUI.TILE_WIDTH;
            food2 = ImageIO.read(new File("assets/food2.png"));
            assert food2.getHeight() == GameGUI.TILE_HEIGHT
                    && food2.getWidth() == GameGUI.TILE_WIDTH;
            food3 = ImageIO.read(new File("assets/food3.png"));
            assert food3.getHeight() == GameGUI.TILE_HEIGHT
                    && food3.getWidth() == GameGUI.TILE_WIDTH;
            door = ImageIO.read(new File("assets/door.png"));
            assert door.getHeight() == GameGUI.TILE_HEIGHT
                    && door.getWidth() == GameGUI.TILE_WIDTH;
            table = ImageIO.read(new File("assets/table.png"));
            assert table.getHeight() == GameGUI.TILE_HEIGHT
                    && table.getWidth() == GameGUI.TILE_WIDTH;
            board = ImageIO.read(new File("assets/board.png"));
            assert board.getHeight() == GameGUI.TILE_HEIGHT
                    && board.getWidth() == GameGUI.TILE_WIDTH;
            
        } catch (IOException e) {
            System.out.println("Exception loading images: " + e.getMessage());
            e.printStackTrace(System.out);
        }
    }
 
    public void update(TileType[][] t, Player player, Customer[] customers) {
        currentTiles = t;
        currentPlayer = player;
        currentCustomers = customers;
        repaint();
    }
 
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawLevel(g);
    }
 
    private void drawLevel(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        if (currentTiles != null) {
            for (int i = 0; i < currentTiles.length; i++) {
                for (int j = 0; j < currentTiles[i].length; j++) {
                    switch (currentTiles[i][j]) {
                        case FLOOR1:
                            g2.drawImage(floor1, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case FLOOR2:
                            g2.drawImage(floor2, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case WALL:
                            g2.drawImage(wall, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case FOOD1:
                            g2.drawImage(food1, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case FOOD2:
                            g2.drawImage(food2, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case FOOD3:
                            g2.drawImage(food3, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case DOOR:
                            g2.drawImage(door, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case TABLE:
                            g2.drawImage(floor1, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            g2.drawImage(table, i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);
                            break;
                        case SCORE:
                            for(int k = i-3; k < i+4; k++){                   
                                g2.drawImage(board, k * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT, null);                                
                                g2.drawImage(board, k * GameGUI.TILE_WIDTH, (j-1) * GameGUI.TILE_HEIGHT, null);
                                g2.drawImage(board, k * GameGUI.TILE_WIDTH, (j-2) * GameGUI.TILE_HEIGHT, null);
                                g2.drawImage(board, k * GameGUI.TILE_WIDTH, (j-3) * GameGUI.TILE_HEIGHT, null);
                            }
                            if (t.getLife() == 0) {
                                g2.setFont(new Font("Arial", Font.BOLD, 50));
                                g2.setColor(Color.RED);
                                g2.drawString("GAME", 11 * GameGUI.TILE_WIDTH, 6 * GameGUI.TILE_HEIGHT);
                                g2.drawString("LOSED", 17 * GameGUI.TILE_WIDTH, 6 * GameGUI.TILE_HEIGHT);
                                g2.setFont(new Font("Arial", Font.BOLD, 30));
                                g2.setColor(Color.BLACK);
                                g2.drawString("LEVEL", 11 * GameGUI.TILE_WIDTH, 7 * GameGUI.TILE_HEIGHT);
                                g2.drawString(Integer.toString(t.getlevel()), 17 * GameGUI.TILE_WIDTH, 7 * GameGUI.TILE_HEIGHT);
                                GameEngine.GameEnded = true;
                            } 
                            else if(t.getlevel() < 4){
                                g2.drawString("Lives  :",  (i-2) * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT);
                                g2.drawString("Score  :",  (i-2) * GameGUI.TILE_WIDTH, (j-1) * GameGUI.TILE_HEIGHT);
                                g2.drawString("Level  :",  (i-2) * GameGUI.TILE_WIDTH, (j-2) * GameGUI.TILE_HEIGHT);                           
                                g2.drawString(Integer.toString(t.getLife()),  i * GameGUI.TILE_WIDTH, j * GameGUI.TILE_HEIGHT);
                                g2.drawString(Integer.toString(t.getscore()),  i * GameGUI.TILE_WIDTH, (j-1) * GameGUI.TILE_HEIGHT);
                                g2.drawString(Integer.toString(t.getlevel()),  i * GameGUI.TILE_WIDTH, (j-2) * GameGUI.TILE_HEIGHT);
                            } else {
                                g2.setFont(new Font("Arial", Font.BOLD, 50));
                                g2.setColor(Color.RED);
                                g2.drawString("GAME", 11 * GameGUI.TILE_WIDTH, 6 * GameGUI.TILE_HEIGHT);
                                g2.drawString("WON", 17 * GameGUI.TILE_WIDTH, 6 * GameGUI.TILE_HEIGHT);
                                g2.setFont(new Font("Arial", Font.BOLD, 30));
                                g2.setColor(Color.BLACK);
                                g2.drawString("LEVEL  :", 11 * GameGUI.TILE_WIDTH, 7 * GameGUI.TILE_HEIGHT);
                                g2.drawString(Integer.toString(t.getlevel()), 17 * GameGUI.TILE_WIDTH, 7 * GameGUI.TILE_HEIGHT);
                            } 
                            break;
                    }
                }
            }
        }
        if (currentCustomers != null) {
            Image customerImage = customer1;
            for (Customer cust : currentCustomers) {
                if (cust != null) {
                    switch (cust.getFoodWanted()) {
                        case 2:
                            customerImage = customer2;
                            break;
                        case 3:
                            customerImage = customer3;
                            break;
                        default:
                            customerImage = customer1;
                            break;
                    }
                    g2.drawImage(customerImage, cust.getX() * GameGUI.TILE_WIDTH, cust.getY() * GameGUI.TILE_HEIGHT, null);
                    drawHealthBar(g2, cust);
                }
            }
        }
        if (currentPlayer != null) {
            Image playerImage = null;
            switch (currentPlayer.getCarriedFoodType()) {
                case 0:
                    playerImage = player;
                    break;
                case 1:
                    playerImage = playerfood1;
                    break;
                case 2:
                    playerImage = playerfood2;
                    break;
                case 3:
                    playerImage = playerfood3;
                    break;
            }
            g2.drawImage(playerImage, currentPlayer.getX() * GameGUI.TILE_WIDTH, currentPlayer.getY() * GameGUI.TILE_HEIGHT, null);
            drawEnergyBar(g2, currentPlayer);
        }
        g2.dispose();
    }
 
    private void drawHealthBar(Graphics2D g2, Customer g) {
        double remainingPatience = (double) g.getPatience() / (double) g.getMaxPatience();
        g2.setColor(Color.RED);
        g2.fill(new Rectangle2D.Double(g.getX() * GameGUI.TILE_WIDTH, g.getY() * GameGUI.TILE_HEIGHT + 29, GameGUI.TILE_WIDTH, GameGUI.BAR_HEIGHT));
        g2.setColor(Color.GREEN);
        g2.fill(new Rectangle2D.Double(g.getX() * GameGUI.TILE_WIDTH, g.getY() * GameGUI.TILE_HEIGHT + 29, GameGUI.TILE_WIDTH * remainingPatience, GameGUI.BAR_HEIGHT));
    }
 
    private void drawEnergyBar(Graphics2D g2, Player p) {
        double remainingStamina = (double) p.getStamina() / (double) p.getMaxStamina();
        g2.setColor(Color.BLUE);
        g2.fill(new Rectangle2D.Double(p.getX() * GameGUI.TILE_WIDTH, p.getY() * GameGUI.TILE_HEIGHT + 29, GameGUI.TILE_WIDTH, GameGUI.BAR_HEIGHT));
        g2.setColor(Color.CYAN);
        g2.fill(new Rectangle2D.Double(p.getX() * GameGUI.TILE_WIDTH, p.getY() * GameGUI.TILE_HEIGHT + 29, GameGUI.TILE_WIDTH * remainingStamina, GameGUI.BAR_HEIGHT));
    }
}
